import React, { createContext, useContext, useEffect, useState } from 'react'
import { User } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'
import { Database } from '../lib/supabase'

type Profile = Database['public']['Tables']['profiles']['Row']

interface AuthContextType {
  user: User | null
  profile: Profile | null
  loading: boolean
  isAdmin: boolean
  signUp: (email: string, password: string, fullName: string) => Promise<void>
  signIn: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  updateProfile: (updates: Partial<Profile>) => Promise<void>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    // Load user on mount
    async function loadUser() {
      try {
        const { data: { user } } = await supabase.auth.getUser()
        setUser(user)
        
        if (user) {
          await loadUserProfile(user.id)
        }
      } finally {
        setLoading(false)
      }
    }
    
    loadUser()

    // Set up auth listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user || null)
        
        if (session?.user) {
          await loadUserProfile(session.user.id)
        } else {
          setProfile(null)
        }
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  async function loadUserProfile(userId: string) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle()

      if (error) {
        console.error('Error loading profile:', error)
        return
      }

      if (data) {
        setProfile(data)
        // Check admin status
        const adminStatus = data.is_admin || data.role === 'admin' || data.subscription_tier === 'ADMIN'
        setIsAdmin(adminStatus)
      } else {
        // Create profile if it doesn't exist
        await setupUserProfile(userId)
      }
    } catch (error) {
      console.error('Error in loadUserProfile:', error)
    }
  }

  async function setupUserProfile(userId: string) {
    try {
      const { data, error } = await supabase.functions.invoke('profile-setup', {
        body: {
          email: user?.email || '',
          full_name: ''
        }
      })

      if (error) {
        console.error('Error setting up profile:', error)
        return
      }

      if (data?.data?.profile) {
        setProfile(data.data.profile)
        // Check admin status for new profile
        const adminStatus = data.data.profile.is_admin || data.data.profile.role === 'admin' || data.data.profile.subscription_tier === 'ADMIN'
        setIsAdmin(adminStatus)
      }
    } catch (error) {
      console.error('Error in setupUserProfile:', error)
    }
  }

  async function signUp(email: string, password: string, fullName: string) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`
      }
    })

    if (error) throw error

    // Set up profile after successful signup
    if (data.user) {
      await supabase.functions.invoke('profile-setup', {
        body: {
          email,
          full_name: fullName
        }
      })
    }
  }

  async function signIn(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    
    if (error) throw error
  }

  async function signOut() {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
    
    // Reset state on signout
    setUser(null)
    setProfile(null)
    setIsAdmin(false)
  }

  // Function to refresh profile data
  async function refreshProfile() {
    if (user) {
      await loadUserProfile(user.id)
    }
  }

  async function updateProfile(updates: Partial<Profile>) {
    if (!user) return
    
    try {
      const { data, error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('user_id', user.id)
        .select()
        .maybeSingle()

      if (error) throw error
      
      if (data) {
        setProfile(data)
        // Update admin status
        const adminStatus = data.is_admin || data.role === 'admin' || data.subscription_tier === 'ADMIN'
        setIsAdmin(adminStatus)
      }
    } catch (error) {
      console.error('Error updating profile:', error)
      throw error
    }
  }

  return (
    <AuthContext.Provider value={{
      user,
      profile,
      loading,
      isAdmin,
      signUp,
      signIn,
      signOut,
      updateProfile,
      refreshProfile
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}