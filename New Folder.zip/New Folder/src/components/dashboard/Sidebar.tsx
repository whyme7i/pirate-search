import React from 'react'
import { motion } from 'framer-motion'
import { 
  MessageSquare, 
  History, 
  BookOpen, 
  Crown, 
  Zap, 
  User,
  TrendingUp,
  Target,
  Calendar,
  X,
  Shield
} from 'lucide-react'
import { Database } from '../../lib/supabase'

type Profile = Database['public']['Tables']['profiles']['Row']
type UsageTracking = Database['public']['Tables']['usage_tracking']['Row']

interface SidebarProps {
  activeTab: 'chat' | 'history' | 'plans'
  onTabChange: (tab: 'chat' | 'history' | 'plans') => void
  profile: Profile
  usageData: UsageTracking | null
  onUpgradeClick: () => void
  onClose?: () => void
  isAdmin?: boolean
}

const Sidebar = ({ activeTab, onTabChange, profile, usageData, onUpgradeClick, onClose, isAdmin = false }: SidebarProps) => {
  const getTierInfo = () => {
    if (isAdmin) {
      return {
        name: 'Admin',
        icon: <Shield className="w-4 h-4" />,
        color: 'from-yellow-400 to-orange-400',
        features: ['Unlimited everything', 'All premium features', 'Admin access', 'Priority support', 'Advanced tools', 'Full system access']
      }
    }
    
    switch (profile.subscription_tier) {
      case 'premium':
        return {
          name: 'Premium',
          icon: <Crown className="w-4 h-4" />,
          color: 'from-yellow-400 to-orange-400',
          features: ['Unlimited questions', 'File uploads (100MB)', 'Camera features', 'Study plans', 'Code debugging', 'Priority support']
        }
      case 'pro':
        return {
          name: 'Pro',
          icon: <Zap className="w-4 h-4" />,
          color: 'from-purple-400 to-blue-400',
          features: ['50 questions/day', 'All subjects + coding', 'File uploads (25MB)', 'Camera capture', 'Question history', 'Code help']
        }
      default:
        return {
          name: 'Free',
          icon: <User className="w-4 h-4" />,
          color: 'from-gray-400 to-gray-500',
          features: ['5 questions/day', 'Basic subjects only', 'Text questions only', 'Simple explanations']
        }
    }
  }

  const tierInfo = getTierInfo()
  const usagePercentage = usageData 
    ? (usageData.questions_asked / usageData.daily_limit) * 100 
    : 0

  const navItems = [
    {
      id: 'chat' as const,
      name: 'Ask Question',
      icon: <MessageSquare className="w-5 h-5" />,
      description: 'Get AI homework help'
    },
    {
      id: 'history' as const,
      name: 'Question History',
      icon: <History className="w-5 h-5" />,
      description: 'View past questions',
      premium: profile.subscription_tier === 'free'
    },
    {
      id: 'plans' as const,
      name: 'Study Plans',
      icon: <BookOpen className="w-5 h-5" />,
      description: 'Personalized study guides',
      premium: profile.subscription_tier !== 'premium'
    }
  ]

  return (
    <div className="w-80 lg:w-64 bg-black/20 backdrop-blur-sm border-r border-white/10 flex flex-col safe-area-top">
      {/* Mobile Close Button */}
      {onClose && (
        <div className="flex justify-end p-4 lg:hidden">
          <button
            onClick={onClose}
            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      )}
      {/* Navigation */}
      <div className="p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Dashboard</h3>
        
        <nav className="space-y-2">
          {navItems.map((item) => (
            <motion.button
              key={item.id}
              onClick={() => {
                if (item.premium) {
                  onUpgradeClick()
                } else {
                  onTabChange(item.id)
                }
              }}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                activeTab === item.id && !item.premium
                  ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white' 
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              } ${item.premium ? 'opacity-75' : ''}`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className={`${activeTab === item.id && !item.premium ? 'text-white' : 'text-white/60 group-hover:text-white'}`}>
                {item.icon}
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center space-x-2">
                  <span className="font-medium">{item.name}</span>
                  {item.premium && (
                    <Crown className="w-4 h-4 text-yellow-400" />
                  )}
                </div>
                <div className={`text-xs ${activeTab === item.id && !item.premium ? 'text-white/80' : 'text-white/50'}`}>
                  {item.description}
                </div>
              </div>
            </motion.button>
          ))}
        </nav>
      </div>

      {/* Usage Stats */}
      <div className="px-6 py-4">
        <div className="glass rounded-xl p-4">
          <h4 className="text-white font-medium mb-3 flex items-center">
            <TrendingUp className="w-4 h-4 mr-2" />
            Today's Usage
          </h4>
          
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-white/70">Questions Asked</span>
              <span className="text-white font-medium">
                {usageData?.questions_asked || 0} / {usageData?.daily_limit || (profile.subscription_tier === 'premium' ? '∞' : profile.subscription_tier === 'pro' ? '50' : '5')}
              </span>
            </div>
            
            {profile.subscription_tier !== 'premium' && (
              <div className="w-full bg-white/10 rounded-full h-2">
                <motion.div
                  className={`h-2 rounded-full bg-gradient-to-r ${
                    usagePercentage >= 90 ? 'from-red-400 to-red-500' :
                    usagePercentage >= 70 ? 'from-yellow-400 to-orange-400' :
                    'from-green-400 to-blue-400'
                  }`}
                  initial={{ width: 0 }}
                  animate={{ width: `${usagePercentage}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
              </div>
            )}
            
            {usagePercentage >= 80 && profile.subscription_tier !== 'premium' && (
              <div className="text-xs text-orange-400 flex items-center">
                <Target className="w-3 h-3 mr-1" />
                Running low on questions!
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Subscription Card */}
      <div className="px-6 py-4 flex-1">
        <div className="glass rounded-xl p-4 h-full flex flex-col">
          <div className="flex items-center space-x-3 mb-4">
            <div className={`w-8 h-8 rounded-lg bg-gradient-to-r ${tierInfo.color} flex items-center justify-center text-white`}>
              {tierInfo.icon}
            </div>
            <div>
              <h4 className="text-white font-semibold">{tierInfo.name} Plan</h4>
              <p className="text-white/60 text-xs">Current subscription</p>
            </div>
          </div>
          
          <div className="space-y-2 mb-4 flex-1">
            {tierInfo.features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-2 text-sm">
                <div className="w-1.5 h-1.5 bg-green-400 rounded-full" />
                <span className="text-white/80">{feature}</span>
              </div>
            ))}
          </div>
          
          {profile.subscription_tier !== 'premium' && (
            <motion.button
              onClick={onUpgradeClick}
              className="btn-premium w-full py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg font-medium text-sm hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300 flex items-center justify-center"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {profile.subscription_tier === 'free' ? (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Upgrade to Pro
                </>
              ) : (
                <>
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade to Premium
                </>
              )}
            </motion.button>
          )}
          
          {profile.subscription_tier === 'premium' && profile.subscription_ends_at && (
            <div className="text-xs text-white/60 text-center flex items-center justify-center">
              <Calendar className="w-3 h-3 mr-1" />
              Renews {new Date(profile.subscription_ends_at).toLocaleDateString()}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Sidebar