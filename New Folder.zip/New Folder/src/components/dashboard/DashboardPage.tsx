import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { supabase } from '../../lib/supabase'
import toast from 'react-hot-toast'
import LoadingScreen from '../LoadingScreen'
import Header from './Header'
import ChatInterface from './ChatInterface'
import Sidebar from './Sidebar'
import SubscriptionModal from './SubscriptionModal'
import QuestionHistory from './QuestionHistory'
import StudyPlans from './StudyPlans'
import { Database } from '../../lib/supabase'

type Subject = Database['public']['Tables']['subjects']['Row']
type Question = Database['public']['Tables']['questions']['Row']
type UsageTracking = Database['public']['Tables']['usage_tracking']['Row']
type Profile = Database['public']['Tables']['profiles']['Row']

interface User {
  id: string
  email?: string
  user_metadata?: {
    full_name?: string
    role?: string
  }
  app_metadata?: {
    role?: string
  }
}

const DashboardPage = () => {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [activeTab, setActiveTab] = useState<'chat' | 'history' | 'plans'>('chat')
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [questions, setQuestions] = useState<Question[]>([])
  const [usageData, setUsageData] = useState<UsageTracking | null>(null)
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    loadUser()
  }, [])

  const loadUser = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        setUser(user as User)
        await loadUserProfile(user.id)
        await loadInitialData()
      }
    } catch (error) {
      console.error('Error loading user:', error)
      toast.error('Failed to load user data')
    } finally {
      setLoading(false)
    }
  }

  const loadUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle()

      if (error) {
        console.error('Error loading profile:', error)
        return
      }

      if (data) {
        setProfile(data)
        // Check admin status
        const adminStatus = data.is_admin || data.role === 'admin' || data.subscription_tier === 'ADMIN'
        setIsAdmin(adminStatus)
      }
    } catch (error) {
      console.error('Error in loadUserProfile:', error)
    }
  }

  const loadInitialData = async () => {
    try {
      await Promise.all([
        loadSubjects(),
        loadQuestions(),
        loadUsageData()
      ])
    } catch (error) {
      console.error('Error loading dashboard data:', error)
      toast.error('Failed to load dashboard data')
    }
  }

  const loadSubjects = async () => {
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .order('name')

      if (error) throw error
      setSubjects(data || [])
    } catch (error) {
      console.error('Error loading subjects:', error)
    }
  }

  const loadQuestions = async () => {
    if (!user) return

    try {
      const { data, error } = await supabase
        .from('questions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50)

      if (error) throw error
      setQuestions(data || [])
    } catch (error) {
      console.error('Error loading questions:', error)
    }
  }

  const loadUsageData = async () => {
    if (!user) return

    try {
      const today = new Date().toISOString().split('T')[0]
      const { data, error } = await supabase
        .from('usage_tracking')
        .select('*')
        .eq('user_id', user.id)
        .eq('date', today)
        .maybeSingle()

      if (error) throw error
      setUsageData(data)
    } catch (error) {
      console.error('Error loading usage data:', error)
    }
  }

  const handleQuestionSubmitted = async () => {
    // Reload questions and usage data after a new question
    await Promise.all([
      loadQuestions(),
      loadUsageData()
    ])
  }

  const handleUpgradeClick = () => {
    // Admin users don't need to upgrade
    if (isAdmin) {
      toast.success('You have admin access with unlimited features!')
      return
    }
    setShowSubscriptionModal(true)
  }

  const closeSidebar = () => {
    setSidebarOpen(false)
  }

  if (loading) {
    return <LoadingScreen message="Loading your dashboard..." />
  }

  if (!user || !profile) {
    return (
      <LoadingScreen message="Setting up your account..." />
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 safe-area-top safe-area-bottom">
      {/* Header */}
      <Header 
        profile={profile}
        usageData={usageData}
        onUpgradeClick={handleUpgradeClick}
        onMenuClick={() => setSidebarOpen(true)}
        isAdmin={isAdmin}
      />

      <div className="flex h-[calc(100vh-80px)] relative">
        {/* Sidebar - Mobile overlay */}
        <div className={`
          fixed inset-y-0 left-0 z-50 w-80 transform transition-transform duration-300 lg:relative lg:translate-x-0 lg:w-64
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          <Sidebar 
            activeTab={activeTab}
            onTabChange={setActiveTab}
            profile={profile}
            usageData={usageData}
            onUpgradeClick={handleUpgradeClick}
            onClose={closeSidebar}
            isAdmin={isAdmin}
          />
        </div>

        {/* Mobile overlay backdrop */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={closeSidebar}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 overflow-hidden bg-gradient-to-br from-slate-900/50 to-purple-900/30">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="h-full"
          >
            {activeTab === 'chat' && (
              <ChatInterface
                subjects={subjects}
                profile={profile}
                usageData={usageData}
                onQuestionSubmitted={handleQuestionSubmitted}
                onUpgradeClick={handleUpgradeClick}
                isAdmin={isAdmin}
              />
            )}
            
            {activeTab === 'history' && (
              <QuestionHistory
                questions={questions}
                subjects={subjects}
                profile={profile}
                onRefresh={loadQuestions}
                isAdmin={isAdmin}
              />
            )}
            
            {activeTab === 'plans' && (
              <StudyPlans
                profile={profile}
                subjects={subjects}
                onUpgradeClick={handleUpgradeClick}
                isAdmin={isAdmin}
              />
            )}
          </motion.div>
        </main>
      </div>

      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <SubscriptionModal
          isOpen={showSubscriptionModal}
          onClose={() => setShowSubscriptionModal(false)}
          currentTier={profile.subscription_tier}
          isAdmin={isAdmin}
        />
      )}
    </div>
  )
}

export default DashboardPage