import React, { useState, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Search, 
  Filter, 
  Star, 
  Calendar, 
  BookOpen, 
  Clock,
  ChevronDown,
  Heart,
  Eye,
  Crown,
  AlertCircle
} from 'lucide-react'
import { Database } from '../../lib/supabase'
import { supabase } from '../../lib/supabase'
import toast from 'react-hot-toast'

type Question = Database['public']['Tables']['questions']['Row']
type Subject = Database['public']['Tables']['subjects']['Row']
type Profile = Database['public']['Tables']['profiles']['Row']

interface QuestionHistoryProps {
  questions: Question[]
  subjects: Subject[]
  profile: Profile
  onRefresh: () => void
  isAdmin?: boolean
}

const QuestionHistory = ({ questions, subjects, profile, onRefresh, isAdmin = false }: QuestionHistoryProps) => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedSubject, setSelectedSubject] = useState('')
  const [selectedDifficulty, setSelectedDifficulty] = useState('')
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'subject'>('newest')
  const [expandedQuestion, setExpandedQuestion] = useState<string | null>(null)
  const [favoriteLoading, setFavoriteLoading] = useState<string | null>(null)

  // Check if user can access history
  const canAccessHistory = isAdmin || profile.subscription_tier !== 'free'

  const subjectMap = useMemo(() => {
    return subjects.reduce((acc, subject) => {
      acc[subject.id] = subject
      return acc
    }, {} as Record<string, Subject>)
  }, [subjects])

  const filteredQuestions = useMemo(() => {
    let filtered = questions

    if (searchTerm) {
      filtered = filtered.filter(q => 
        q.question_text.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.ai_response.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    if (selectedSubject) {
      filtered = filtered.filter(q => q.subject_id === selectedSubject)
    }

    if (selectedDifficulty) {
      filtered = filtered.filter(q => q.difficulty_level === selectedDifficulty)
    }

    // Sort questions
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        case 'oldest':
          return new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        case 'subject':
          const subjectA = subjectMap[a.subject_id || '']?.name || ''
          const subjectB = subjectMap[b.subject_id || '']?.name || ''
          return subjectA.localeCompare(subjectB)
        default:
          return 0
      }
    })

    return filtered
  }, [questions, searchTerm, selectedSubject, selectedDifficulty, sortBy, subjectMap])

  const toggleFavorite = async (questionId: string, currentFavorite: boolean) => {
    setFavoriteLoading(questionId)
    
    try {
      const { error } = await supabase
        .from('questions')
        .update({ is_favorite: !currentFavorite })
        .eq('id', questionId)

      if (error) throw error
      
      toast.success(currentFavorite ? 'Removed from favorites' : 'Added to favorites')
      onRefresh()
    } catch (error) {
      console.error('Error updating favorite:', error)
      toast.error('Failed to update favorite')
    } finally {
      setFavoriteLoading(null)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 3600)
    
    if (diffInHours < 24) {
      return `${Math.floor(diffInHours)} hours ago`
    } else if (diffInHours < 48) {
      return 'Yesterday'
    } else {
      return date.toLocaleDateString()
    }
  }

  if (!canAccessHistory) {
    return (
      <div className="h-full flex items-center justify-center p-8">
        <motion.div
          className="text-center max-w-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Crown className="w-10 h-10 text-white" />
          </div>
          
          <h2 className="text-2xl font-bold text-white mb-4">Question History</h2>
          <p className="text-white/70 mb-6 leading-relaxed">
            Keep track of all your homework questions and AI responses. Upgrade to Pro or Premium to access this feature and build your personal study library.
          </p>
          
          <div className="glass rounded-xl p-4 mb-6">
            <h3 className="text-white font-semibold mb-2">With Pro or Premium you get:</h3>
            <div className="space-y-2 text-sm text-white/80">
              <div className="flex items-center space-x-2">
                <Star className="w-4 h-4 text-yellow-400" />
                <span>Complete question history</span>
              </div>
              <div className="flex items-center space-x-2">
                <Heart className="w-4 h-4 text-red-400" />
                <span>Favorite important questions</span>
              </div>
              <div className="flex items-center space-x-2">
                <Search className="w-4 h-4 text-blue-400" />
                <span>Search and filter capabilities</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-slate-900/50 to-purple-900/30">
      {/* Header */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Question History</h2>
            <p className="text-white/70">
              {questions.length} questions asked • {questions.filter(q => q.is_favorite).length} favorites
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
            <input
              type="text"
              placeholder="Search questions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all duration-200"
            />
          </div>

          {/* Subject Filter */}
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all duration-200"
          >
            <option value="" className="bg-gray-800">All subjects</option>
            {subjects.map((subject) => (
              <option key={subject.id} value={subject.id} className="bg-gray-800">
                {subject.name}
              </option>
            ))}
          </select>

          {/* Difficulty Filter */}
          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all duration-200"
          >
            <option value="" className="bg-gray-800">All difficulties</option>
            <option value="Elementary" className="bg-gray-800">Elementary</option>
            <option value="Middle School" className="bg-gray-800">Middle School</option>
            <option value="High School" className="bg-gray-800">High School</option>
            <option value="College" className="bg-gray-800">College</option>
          </select>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'newest' | 'oldest' | 'subject')}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all duration-200"
          >
            <option value="newest" className="bg-gray-800">Newest first</option>
            <option value="oldest" className="bg-gray-800">Oldest first</option>
            <option value="subject" className="bg-gray-800">By subject</option>
          </select>
        </div>
      </div>

      {/* Questions List */}
      <div className="flex-1 overflow-y-auto p-6">
        {filteredQuestions.length === 0 ? (
          <div className="text-center py-12">
            <AlertCircle className="w-12 h-12 text-white/40 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">No questions found</h3>
            <p className="text-white/60">
              {questions.length === 0 
                ? "You haven't asked any questions yet. Go to the chat to get started!"
                : "Try adjusting your search filters to find what you're looking for."
              }
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <AnimatePresence>
              {filteredQuestions.map((question) => {
                const subject = subjectMap[question.subject_id || '']
                const isExpanded = expandedQuestion === question.id
                
                return (
                  <motion.div
                    key={question.id}
                    className="glass rounded-xl overflow-hidden"
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                  >
                    {/* Question Header */}
                    <div className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            {subject && (
                              <span className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm font-medium">
                                {subject.name}
                              </span>
                            )}
                            <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm font-medium">
                              {question.difficulty_level}
                            </span>
                            {question.is_favorite && (
                              <Star className="w-4 h-4 text-yellow-400 fill-current" />
                            )}
                          </div>
                          
                          <h3 className="text-white font-semibold mb-2 line-clamp-2">
                            {question.question_text}
                          </h3>
                          
                          <div className="flex items-center space-x-4 text-sm text-white/60">
                            <div className="flex items-center space-x-1">
                              <Calendar className="w-4 h-4" />
                              <span>{formatDate(question.created_at)}</span>
                            </div>
                            
                            {question.response_time_ms && (
                              <div className="flex items-center space-x-1">
                                <Clock className="w-4 h-4" />
                                <span>{(question.response_time_ms / 1000).toFixed(1)}s</span>
                              </div>
                            )}
                            
                            {question.has_file_upload && (
                              <div className="flex items-center space-x-1">
                                <BookOpen className="w-4 h-4" />
                                <span>With files</span>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => toggleFavorite(question.id, question.is_favorite)}
                            disabled={favoriteLoading === question.id}
                            className={`p-2 rounded-lg transition-all duration-200 ${
                              question.is_favorite 
                                ? 'text-yellow-400 bg-yellow-400/10 hover:bg-yellow-400/20'
                                : 'text-white/40 hover:text-yellow-400 hover:bg-yellow-400/10'
                            }`}
                          >
                            <Heart className={`w-4 h-4 ${question.is_favorite ? 'fill-current' : ''}`} />
                          </button>
                          
                          <button
                            onClick={() => setExpandedQuestion(isExpanded ? null : question.id)}
                            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
                          >
                            <motion.div
                              animate={{ rotate: isExpanded ? 180 : 0 }}
                              transition={{ duration: 0.2 }}
                            >
                              <ChevronDown className="w-4 h-4" />
                            </motion.div>
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    {/* Expanded Content */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                          className="border-t border-white/10"
                        >
                          <div className="p-6">
                            <div className="mb-4">
                              <h4 className="text-white font-medium mb-2">Question:</h4>
                              <p className="text-white/80 whitespace-pre-wrap">{question.question_text}</p>
                            </div>
                            
                            <div>
                              <h4 className="text-white font-medium mb-2">AI Response:</h4>
                              <div className="glass rounded-lg p-4">
                                <p className="text-white/90 whitespace-pre-wrap">{question.ai_response}</p>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                )
              })}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  )
}

export default QuestionHistory