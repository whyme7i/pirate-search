import React, { useState, useRef, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Send, 
  Upload, 
  Loader2, 
  FileText, 
  Image as ImageIcon,
  X,
  Zap,
  Crown,
  AlertCircle,
  Camera,
  Code,
  Play,
  Eye,
  Download,
  Shield
} from 'lucide-react'
import { useDropzone } from 'react-dropzone'
import Webcam, { WebcamProps } from 'react-webcam'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { supabase } from '../../lib/supabase'
import { Database } from '../../lib/supabase'
import toast from 'react-hot-toast'

type Profile = Database['public']['Tables']['profiles']['Row']
type Subject = Database['public']['Tables']['subjects']['Row']
type UsageTracking = Database['public']['Tables']['usage_tracking']['Row']

interface Message {
  id: string
  type: 'user' | 'ai'
  content: string
  subject?: string
  difficulty?: string
  timestamp: Date
  isTyping?: boolean
  files?: Array<{ name: string; url: string; type: string; category?: string }>
  codeBlocks?: Array<{ language: string; code: string }>
}

interface ChatInterfaceProps {
  subjects: Subject[]
  profile: Profile
  usageData: UsageTracking | null
  onQuestionSubmitted: () => void
  onUpgradeClick: () => void
  isAdmin?: boolean
}

interface UploadedFile {
  name: string
  url: string
  type: string
  content?: string
  category?: string
  preview?: string
}

const ChatInterface = ({ 
  subjects, 
  profile, 
  usageData, 
  onQuestionSubmitted, 
  onUpgradeClick,
  isAdmin = false
}: ChatInterfaceProps) => {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputText, setInputText] = useState('')
  const [selectedSubject, setSelectedSubject] = useState('')
  const [selectedDifficulty, setSelectedDifficulty] = useState('')
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [showCamera, setShowCamera] = useState(false)
  const [showFilePreview, setShowFilePreview] = useState<UploadedFile | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const webcamRef = useRef<any>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    // Add welcome message on mount
    if (messages.length === 0) {
      const welcomeMessage = `Welcome to HomeworkAI! I'm here to help you with your homework questions. 

${isAdmin ? '🔥 ADMIN ACCESS: You have unlimited access to all features with no restrictions!' : 
  profile.subscription_tier === 'free' ? 'You have access to Math, Science, and English questions with text input only.' : 
  profile.subscription_tier === 'pro' ? 'You have access to all subjects, file uploads up to 25MB, and coding assistance!' : 
  'You have unlimited access to all subjects, file uploads up to 100MB, camera capture, and advanced coding support!'} 

To get started, select a subject and difficulty level, then ask me your question!`
      
      setMessages([{
        id: '1',
        type: 'ai',
        content: welcomeMessage,
        timestamp: new Date()
      }])
    }
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const canAskQuestion = () => {
    if (isAdmin || profile.subscription_tier === 'premium') return true
    
    const limit = profile.subscription_tier === 'pro' ? 50 : 5
    const used = usageData?.questions_asked || 0
    return used < limit
  }

  const canUploadFiles = () => {
    return isAdmin || profile.subscription_tier === 'pro' || profile.subscription_tier === 'premium'
  }

  const canUseCamera = () => {
    return isAdmin || profile.subscription_tier === 'pro' || profile.subscription_tier === 'premium'
  }

  const remainingQuestions = () => {
    if (isAdmin || profile.subscription_tier === 'premium') return 'unlimited'
    
    const limit = profile.subscription_tier === 'pro' ? 50 : 5
    const used = usageData?.questions_asked || 0
    return Math.max(0, limit - used)
  }

  const getFileIcon = (file: UploadedFile) => {
    if (file.type.startsWith('image/')) return <ImageIcon className="w-4 h-4" />
    if (file.category === 'code') return <Code className="w-4 h-4" />
    return <FileText className="w-4 h-4" />
  }

  const getFileSizeLimit = () => {
    if (isAdmin) return 500 // 500MB for admin
    const limits = {
      'free': 0,
      'pro': 25,
      'premium': 100
    }
    return limits[profile.subscription_tier] || 0
  }

  // Drag and drop functionality
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (!canUploadFiles()) {
      toast.error('File uploads are only available for Pro and Premium subscribers')
      return
    }

    for (const file of acceptedFiles) {
      const maxSize = getFileSizeLimit() * 1024 * 1024
      if (file.size > maxSize) {
        toast.error(`File ${file.name} is too large. Maximum size is ${getFileSizeLimit()}MB for ${profile.subscription_tier} tier.`)
        continue
      }

      await uploadFile(file)
    }
  }, [profile.subscription_tier])

  const dropzoneConfig = {
    onDrop,
    disabled: !canUploadFiles(),
    multiple: true,
    accept: {
      'image/*': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'],
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
      'text/x-python': ['.py'],
      'text/javascript': ['.js'],
      'text/x-java-source': ['.java'],
      'text/x-c++src': ['.cpp'],
      'text/x-csrc': ['.c'],
      'text/html': ['.html'],
      'text/css': ['.css'],
      'application/json': ['.json'],
      'text/x-sql': ['.sql'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    } as any
  }

  const { getRootProps, getInputProps, isDragActive } = useDropzone(dropzoneConfig as any)

  const uploadFile = async (file: File) => {
    try {
      const reader = new FileReader()
      reader.onload = async (e) => {
        const fileData = e.target?.result as string
        
        // Create preview for images
        let preview = ''
        if (file.type.startsWith('image/')) {
          preview = fileData
        }
        
        // Upload file using edge function
        const { data, error } = await supabase.functions.invoke('file-upload', {
          body: {
            fileData,
            fileName: file.name,
            fileType: file.type
          }
        })

        if (error) {
          toast.error(`Failed to upload ${file.name}: ${error.message}`)
          return
        }

        if (data?.data) {
          setUploadedFiles(prev => [...prev, {
            name: file.name,
            url: data.data.publicUrl,
            type: file.type,
            content: data.data.extractedContent,
            category: data.data.fileCategory,
            preview
          }])
          toast.success(`${file.name} uploaded successfully`)
        }
      }
      
      reader.readAsDataURL(file)
    } catch (error) {
      console.error('File upload error:', error)
      toast.error(`Failed to upload ${file.name}`)
    }
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files || files.length === 0) return

    for (const file of Array.from(files)) {
      await uploadFile(file)
    }
  }

  const capturePhoto = useCallback(() => {
    if (!webcamRef.current) return
    
    const imageSrc = webcamRef.current.getScreenshot()
    if (!imageSrc) return

    // Convert to file and upload
    fetch(imageSrc)
      .then(res => res.blob())
      .then(blob => {
        const file = new File([blob], `homework-photo-${Date.now()}.jpg`, { type: 'image/jpeg' })
        uploadFile(file)
      })
      .catch(error => {
        console.error('Error capturing photo:', error)
        toast.error('Failed to capture photo')
      })
    
    setShowCamera(false)
  }, [])

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index))
  }

  const extractCodeBlocks = (content: string): Array<{ language: string; code: string }> => {
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g
    const blocks: Array<{ language: string; code: string }> = []
    let match

    while ((match = codeBlockRegex.exec(content)) !== null) {
      blocks.push({
        language: match[1] || 'text',
        code: match[2].trim()
      })
    }

    return blocks
  }

  const renderMessageContent = (message: Message) => {
    const codeBlocks = extractCodeBlocks(message.content)
    
    if (codeBlocks.length === 0) {
      return <div className="whitespace-pre-wrap text-base leading-7">{message.content}</div>
    }

    // Split content by code blocks and render with syntax highlighting
    let lastIndex = 0
    const parts: React.ReactNode[] = []
    
    codeBlocks.forEach((block, index) => {
      const blockStart = message.content.indexOf('```', lastIndex)
      const blockEnd = message.content.indexOf('```', blockStart + 3) + 3
      
      // Add text before code block
      if (blockStart > lastIndex) {
        const textBefore = message.content.slice(lastIndex, blockStart)
        parts.push(
          <div key={`text-${index}`} className="whitespace-pre-wrap text-base leading-7 mb-6">
            {textBefore}
          </div>
        )
      }
      
      // Add code block with syntax highlighting
      parts.push(
        <div key={`code-${index}`} className="mb-6 rounded-lg overflow-hidden">
          <div className="flex items-center justify-between bg-gray-800 px-4 py-2 text-sm">
            <span className="text-gray-300">{block.language}</span>
            <button
              onClick={() => navigator.clipboard.writeText(block.code)}
              className="text-gray-400 hover:text-white transition-colors"
            >
              Copy
            </button>
          </div>
          <SyntaxHighlighter
            language={block.language}
            style={vscDarkPlus}
            customStyle={{
              margin: 0,
              borderRadius: 0,
              background: '#1e1e1e',
              fontSize: '14px',
              lineHeight: '1.5'
            }}
          >
            {block.code}
          </SyntaxHighlighter>
        </div>
      )
      
      lastIndex = blockEnd
    })
    
    // Add remaining text
    if (lastIndex < message.content.length) {
      const remainingText = message.content.slice(lastIndex)
      parts.push(
        <div key="text-end" className="whitespace-pre-wrap text-base leading-7">
          {remainingText}
        </div>
      )
    }
    
    return <div className="space-y-2">{parts}</div>
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!inputText.trim()) {
      toast.error('Please enter a question')
      return
    }

    if (!selectedSubject) {
      toast.error('Please select a subject')
      return
    }

    if (!selectedDifficulty) {
      toast.error('Please select a difficulty level')
      return
    }

    if (!canAskQuestion()) {
      toast.error('You have reached your daily question limit. Please upgrade to continue.')
      return
    }

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputText,
      subject: selectedSubject,
      difficulty: selectedDifficulty,
      timestamp: new Date(),
      files: uploadedFiles.map(f => ({ name: f.name, url: f.url, type: f.type, category: f.category }))
    }

    setMessages(prev => [...prev, userMessage])
    setInputText('')
    setIsLoading(true)

    // Add typing indicator
    const typingMessage: Message = {
      id: 'typing',
      type: 'ai',
      content: '',
      timestamp: new Date(),
      isTyping: true
    }
    setMessages(prev => [...prev, typingMessage])

    try {
      // Call homework AI function
      const { data, error } = await supabase.functions.invoke('homework-ai', {
        body: {
          question: inputText,
          subject: selectedSubject,
          difficulty_level: selectedDifficulty,
          context_files: uploadedFiles.map(f => f.content).filter(Boolean)
        }
      })

      // Remove typing indicator
      setMessages(prev => prev.filter(msg => msg.id !== 'typing'))

      if (error) {
        throw new Error(error.message || 'Failed to get AI response')
      }

      if (data?.data) {
        // Add AI response with typing effect
        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: 'ai',
          content: data.data.response,
          timestamp: new Date(),
          codeBlocks: extractCodeBlocks(data.data.response)
        }
        
        setMessages(prev => [...prev, aiMessage])
        
        // Clear uploaded files after successful submission
        setUploadedFiles([])
        
        // Call the callback to refresh data
        onQuestionSubmitted()
        
        // Show remaining questions info
        if (data.data.remaining_questions !== 'unlimited') {
          toast.success(`Question answered! ${data.data.remaining_questions} questions remaining today.`)
        }
      }
    } catch (error: any) {
      // Remove typing indicator
      setMessages(prev => prev.filter(msg => msg.id !== 'typing'))
      
      console.error('Chat error:', error)
      
      // Add error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: `I apologize, but I encountered an error: ${error.message}. Please try again or contact support if the problem persists.`,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
      
      toast.error(error.message || 'Failed to get AI response')
    } finally {
      setIsLoading(false)
    }
  }

  const availableSubjects = subjects.filter(subject => 
    profile.subscription_tier !== 'free' || subject.is_free_tier
  )

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-slate-900/50 to-purple-900/30 safe-area-bottom">
      {/* Chat Header */}
      <div className="p-4 md:p-6 border-b border-white/10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl md:text-2xl font-bold text-white flex items-center">
            Homework Assistant
            {isAdmin && (
              <span className="ml-3 admin-badge text-xs px-2 py-1">
                <Shield className="w-3 h-3 mr-1 inline" />
                ADMIN
              </span>
            )}
          </h2>
          <div className="flex items-center space-x-2 md:space-x-4">
            {!canAskQuestion() && !isAdmin && (
              <motion.button
                onClick={onUpgradeClick}
                className="btn-premium px-3 py-2 md:px-4 md:py-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg font-medium text-sm hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300 flex items-center"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Zap className="w-4 h-4 mr-2" />
                Upgrade Now
              </motion.button>
            )}
            <div className="text-white/60 text-sm">
              {remainingQuestions()} questions remaining
            </div>
          </div>
        </div>

        {/* Subject and Difficulty Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-white/90 text-sm font-medium mb-2">
              Subject
            </label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="form-input w-full"
            >
              <option value="">Select a subject</option>
              {availableSubjects.map((subject) => (
                <option key={subject.id} value={subject.name} className="bg-gray-800">
                  {subject.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-white/90 text-sm font-medium mb-2">
              Difficulty Level
            </label>
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="form-input w-full"
            >
              <option value="">Select difficulty</option>
              <option value="Elementary" className="bg-gray-800">Elementary</option>
              <option value="Middle School" className="bg-gray-800">Middle School</option>
              <option value="High School" className="bg-gray-800">High School</option>
              <option value="College" className="bg-gray-800">College</option>
            </select>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
      <div className={`${message.type === 'user' ? 'max-w-2xl' : 'max-w-5xl'} rounded-2xl p-6 ${
                message.type === 'user' 
                  ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white' 
                  : 'glass text-white'
              }`}>
                {message.isTyping ? (
                  <div className="flex items-center space-x-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-white/70">AI is thinking...</span>
                  </div>
                ) : (
                  <>
                    {message.type === 'user' && (
                      <div className="mb-2 text-sm opacity-80">
                        <span className="font-medium">{message.subject}</span> • {message.difficulty}
                      </div>
                    )}
                    
                    {message.files && message.files.length > 0 && (
                      <div className="mb-3 flex flex-wrap gap-2">
                        {message.files.map((file, index) => (
                          <div key={index} className="flex items-center space-x-2 bg-white/10 rounded-lg px-3 py-1 text-sm">
                            {file.type.startsWith('image/') ? (
                              <ImageIcon className="w-4 h-4" />
                            ) : file.category === 'code' ? (
                              <Code className="w-4 h-4" />
                            ) : (
                              <FileText className="w-4 h-4" />
                            )}
                            <span>{file.name}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    <div className="text-base leading-relaxed">{renderMessageContent(message)}</div>
                    
                    <div className="mt-2 text-xs opacity-60">
                      {message.timestamp.toLocaleTimeString()}
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* File Upload Area */}
      {uploadedFiles.length > 0 && (
        <div className="px-6 py-3 border-t border-white/10">
          <div className="flex flex-wrap gap-2">
            {uploadedFiles.map((file, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center space-x-2 bg-white/10 rounded-lg px-3 py-2 text-sm text-white group"
              >
                {getFileIcon(file)}
                <span className="truncate max-w-32">{file.name}</span>
                {file.preview && (
                  <button
                    onClick={() => setShowFilePreview(file)}
                    className="text-blue-400 hover:text-blue-300 transition-colors"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => removeFile(index)}
                  className="text-red-400 hover:text-red-300 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="p-6 border-t border-white/10">
        {!canAskQuestion() && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 p-4 bg-orange-500/20 border border-orange-500/30 rounded-lg flex items-center space-x-3"
          >
            <AlertCircle className="w-5 h-5 text-orange-400 flex-shrink-0" />
            <div className="text-orange-200">
              <p className="font-medium">Daily limit reached!</p>
              <p className="text-sm">Upgrade to {profile.subscription_tier === 'free' ? 'Pro' : 'Premium'} for {profile.subscription_tier === 'free' ? '50 questions' : 'unlimited questions'} per day.</p>
            </div>
            <button
              onClick={onUpgradeClick}
              className="btn-premium px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-lg font-medium text-sm hover:from-orange-600 hover:to-red-600 transform hover:scale-105 transition-all duration-300 flex items-center flex-shrink-0"
            >
              <Crown className="w-4 h-4 mr-2" />
              Upgrade
            </button>
          </motion.div>
        )}
        
        {/* Drag and Drop Zone */}
        {canUploadFiles() && (
          <div
            {...getRootProps()}
            className={`mb-4 border-2 border-dashed rounded-xl p-4 text-center transition-all duration-200 ${
              isDragActive
                ? 'border-purple-400 bg-purple-500/10'
                : 'border-white/20 hover:border-white/40 bg-white/5'
            }`}
          >
            <input {...(getInputProps() as any)} />
            <Upload className="w-8 h-8 text-white/60 mx-auto mb-2" />
            <p className="text-white/70 text-sm">
              {isDragActive
                ? 'Drop files here...'
                : `Drag & drop files here, or click to select (up to ${getFileSizeLimit()}MB)`
              }
            </p>
            <p className="text-white/50 text-xs mt-1">
              Supports: Images, PDFs, Documents, Code files (.py, .js, .java, .cpp, etc.)
            </p>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="flex items-end space-x-4">
          <div className="flex-1">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={canAskQuestion() ? "Ask me any homework question..." : "Upgrade to continue asking questions..."}
              disabled={!canAskQuestion() || isLoading}
              className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all duration-200 resize-none"
              rows={3}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  handleSubmit(e)
                }
              }}
            />
          </div>
          
          <div className="flex flex-col space-y-2">
            {canUseCamera() && (
              <button
                type="button"
                onClick={() => setShowCamera(true)}
                disabled={isLoading}
                className="p-3 bg-white/10 border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                title="Take photo"
              >
                <Camera className="w-5 h-5" />
              </button>
            )}
            
            {canUploadFiles() && (
              <>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*,.pdf,.txt,.py,.js,.java,.cpp,.c,.html,.css,.sql,.json,.doc,.docx,.md"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isLoading}
                  className="p-3 bg-white/10 border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  title="Upload files"
                >
                  <Upload className="w-5 h-5" />
                </button>
              </>
            )}
            
            <button
              type="submit"
              disabled={!canAskQuestion() || isLoading || !inputText.trim() || !selectedSubject || !selectedDifficulty}
              className="p-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center"
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </button>
          </div>
        </form>
        
        <div className="mt-3 text-white/50 text-sm text-center">
          Press Enter to send, Shift+Enter for new line
          {canUploadFiles() && " • Drag files anywhere to upload"}
          {canUseCamera() && " • Use camera for instant capture"}
        </div>
      </div>

      {/* Camera Modal */}
      <AnimatePresence>
        {showCamera && (
          <motion.div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowCamera(false)}
          >
            <motion.div
              className="bg-slate-900/95 backdrop-blur-sm rounded-3xl border border-white/20 p-6 max-w-2xl w-full"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Take Photo</h3>
                <button
                  onClick={() => setShowCamera(false)}
                  className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="relative">
                {React.createElement(Webcam as any, {
                  ref: webcamRef,
                  audio: false,
                  screenshotFormat: "image/jpeg",
                  className: "w-full rounded-xl",
                  videoConstraints: {
                    facingMode: 'environment' // Use back camera on mobile
                  }
                })}
              </div>
              
              <div className="flex justify-center mt-6">
                <button
                  onClick={capturePhoto}
                  className="btn-premium px-8 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl font-semibold hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300 flex items-center"
                >
                  <Camera className="w-5 h-5 mr-2" />
                  Capture Photo
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* File Preview Modal */}
      <AnimatePresence>
        {showFilePreview && (
          <motion.div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowFilePreview(null)}
          >
            <motion.div
              className="bg-slate-900/95 backdrop-blur-sm rounded-3xl border border-white/20 p-6 max-w-4xl w-full max-h-[90vh] overflow-auto"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">{showFilePreview.name}</h3>
                <button
                  onClick={() => setShowFilePreview(null)}
                  className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="text-center">
                {showFilePreview.preview && (
                  <img
                    src={showFilePreview.preview}
                    alt={showFilePreview.name}
                    className="max-w-full max-h-96 mx-auto rounded-lg"
                  />
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default ChatInterface