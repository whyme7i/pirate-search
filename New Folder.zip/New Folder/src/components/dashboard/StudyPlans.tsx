import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  BookOpen, 
  Target, 
  Calendar, 
  Plus, 
  Crown, 
  TrendingUp,
  CheckCircle,
  Clock,
  Star,
  Edit3,
  Trash2,
  AlertCircle
} from 'lucide-react'
import { Database } from '../../lib/supabase'
import { supabase } from '../../lib/supabase'
import toast from 'react-hot-toast'

type Profile = Database['public']['Tables']['profiles']['Row']
type Subject = Database['public']['Tables']['subjects']['Row']
type StudyPlan = Database['public']['Tables']['study_plans']['Row']

interface StudyPlansProps {
  profile: Profile
  subjects: Subject[]
  onUpgradeClick: () => void
  isAdmin?: boolean
}

interface WeeklyGoal {
  subject: string
  target: number
  completed: number
}

const StudyPlans = ({ profile, subjects, onUpgradeClick, isAdmin = false }: StudyPlansProps) => {
  const [studyPlans, setStudyPlans] = useState<StudyPlan[]>([])
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [loading, setLoading] = useState(true)
  const [createLoading, setCreateLoading] = useState(false)
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    subjects: [] as string[],
    difficulty_level: '',
    weekly_goals: {} as Record<string, number>
  })

  const canAccessStudyPlans = isAdmin || profile.subscription_tier === 'premium'

  useEffect(() => {
    if (canAccessStudyPlans) {
      loadStudyPlans()
    } else {
      setLoading(false)
    }
  }, [canAccessStudyPlans, profile.user_id])

  const loadStudyPlans = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('study_plans')
        .select('*')
        .eq('user_id', profile.user_id)
        .eq('is_active', true)
        .order('created_at', { ascending: false })

      if (error) throw error
      setStudyPlans(data || [])
    } catch (error) {
      console.error('Error loading study plans:', error)
      toast.error('Failed to load study plans')
    } finally {
      setLoading(false)
    }
  }

  const handleCreatePlan = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.title.trim()) {
      toast.error('Please enter a title')
      return
    }

    if (formData.subjects.length === 0) {
      toast.error('Please select at least one subject')
      return
    }

    setCreateLoading(true)
    
    try {
      const { error } = await supabase
        .from('study_plans')
        .insert({
          user_id: profile.user_id,
          title: formData.title,
          description: formData.description,
          subjects: formData.subjects,
          difficulty_level: formData.difficulty_level,
          weekly_goals: formData.weekly_goals,
          progress_data: {},
          is_active: true
        })

      if (error) throw error
      
      toast.success('Study plan created successfully!')
      setShowCreateForm(false)
      setFormData({
        title: '',
        description: '',
        subjects: [],
        difficulty_level: '',
        weekly_goals: {}
      })
      loadStudyPlans()
    } catch (error) {
      console.error('Error creating study plan:', error)
      toast.error('Failed to create study plan')
    } finally {
      setCreateLoading(false)
    }
  }

  const toggleSubject = (subjectName: string) => {
    setFormData(prev => {
      const newSubjects = prev.subjects.includes(subjectName)
        ? prev.subjects.filter(s => s !== subjectName)
        : [...prev.subjects, subjectName]
      
      return { ...prev, subjects: newSubjects }
    })
  }

  const updateWeeklyGoal = (subject: string, target: number) => {
    setFormData(prev => ({
      ...prev,
      weekly_goals: {
        ...prev.weekly_goals,
        [subject]: target
      }
    }))
  }

  const getSubjectIcon = (subjectName: string) => {
    const subject = subjects.find(s => s.name === subjectName)
    return subject?.icon || 'book-open'
  }

  if (!canAccessStudyPlans) {
    return (
      <div className="h-full flex items-center justify-center p-8">
        <motion.div
          className="text-center max-w-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full flex items-center justify-center mx-auto mb-6">
            <Crown className="w-10 h-10 text-white" />
          </div>
          
          <h2 className="text-2xl font-bold text-white mb-4">Personalized Study Plans</h2>
          <p className="text-white/70 mb-6 leading-relaxed">
            Create customized study plans with weekly goals, progress tracking, and AI-powered recommendations. 
            This premium feature helps you stay organized and achieve your academic goals.
          </p>
          
          <div className="glass rounded-xl p-6 mb-6">
            <h3 className="text-white font-semibold mb-4">Premium Study Plans Include:</h3>
            <div className="space-y-3 text-sm text-white/80">
              <div className="flex items-center space-x-3">
                <Target className="w-4 h-4 text-green-400" />
                <span>Personalized weekly goals</span>
              </div>
              <div className="flex items-center space-x-3">
                <TrendingUp className="w-4 h-4 text-blue-400" />
                <span>Progress tracking & analytics</span>
              </div>
              <div className="flex items-center space-x-3">
                <Calendar className="w-4 h-4 text-purple-400" />
                <span>Smart scheduling recommendations</span>
              </div>
              <div className="flex items-center space-x-3">
                <Star className="w-4 h-4 text-yellow-400" />
                <span>AI-powered study insights</span>
              </div>
            </div>
          </div>
          
          <motion.button
            onClick={onUpgradeClick}
            className="btn-premium px-8 py-3 bg-gradient-to-r from-yellow-400 to-orange-400 text-black rounded-xl font-semibold hover:from-yellow-500 hover:to-orange-500 transform hover:scale-105 transition-all duration-300 flex items-center justify-center mx-auto"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Crown className="w-5 h-5 mr-2" />
            Upgrade to Premium
          </motion.button>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-slate-900/50 to-purple-900/30">
      {/* Header */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Study Plans</h2>
            <p className="text-white/70">
              Create and manage personalized study plans to achieve your academic goals
            </p>
          </div>
          
          <motion.button
            onClick={() => setShowCreateForm(true)}
            className="btn-premium px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl font-semibold hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300 flex items-center"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Plus className="w-5 h-5 mr-2" />
            Create Plan
          </motion.button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
          </div>
        ) : studyPlans.length === 0 ? (
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 text-white/40 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No Study Plans Yet</h3>
            <p className="text-white/60 mb-6">
              Create your first study plan to start organizing your learning journey with personalized goals and progress tracking.
            </p>
            <button
              onClick={() => setShowCreateForm(true)}
              className="btn-premium px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl font-semibold hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300"
            >
              Create Your First Plan
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {studyPlans.map((plan) => (
              <motion.div
                key={plan.id}
                className="glass rounded-xl p-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-white mb-2">{plan.title}</h3>
                    {plan.description && (
                      <p className="text-white/70 text-sm mb-3">{plan.description}</p>
                    )}
                    
                    <div className="flex items-center space-x-4 text-sm text-white/60">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>Created {new Date(plan.created_at).toLocaleDateString()}</span>
                      </div>
                      
                      {plan.difficulty_level && (
                        <span className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded text-xs">
                          {plan.difficulty_level}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200">
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-white/60 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all duration-200">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                
                {/* Subjects */}
                <div className="mb-4">
                  <h4 className="text-white font-medium mb-2">Subjects</h4>
                  <div className="flex flex-wrap gap-2">
                    {plan.subjects.map((subject, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm"
                      >
                        {subject}
                      </span>
                    ))}
                  </div>
                </div>
                
                {/* Weekly Goals */}
                {plan.weekly_goals && Object.keys(plan.weekly_goals).length > 0 && (
                  <div>
                    <h4 className="text-white font-medium mb-3">Weekly Goals</h4>
                    <div className="space-y-2">
                      {Object.entries(plan.weekly_goals).map(([subject, target]) => (
                        <div key={subject} className="flex items-center justify-between">
                          <span className="text-white/80 text-sm">{subject}</span>
                          <div className="flex items-center space-x-2">
                            <div className="w-24 bg-white/10 rounded-full h-2">
                              <div 
                                className="bg-gradient-to-r from-green-400 to-blue-400 h-2 rounded-full"
                                style={{ width: '60%' }} // This would be calculated based on actual progress
                              />
                            </div>
                            <span className="text-white/60 text-xs">
                              {Math.floor((target as number) * 0.6)}/{target as number} questions
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Create Plan Modal */}
      <AnimatePresence>
        {showCreateForm && (
          <motion.div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowCreateForm(false)}
          >
            <motion.div
              className="bg-slate-900/95 backdrop-blur-sm rounded-3xl border border-white/20 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
            >
              <form onSubmit={handleCreatePlan} className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-white">Create Study Plan</h3>
                  <button
                    type="button"
                    onClick={() => setShowCreateForm(false)}
                    className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
                  >
                    <AlertCircle className="w-6 h-6" />
                  </button>
                </div>
                
                <div className="space-y-6">
                  {/* Title */}
                  <div>
                    <label className="block text-white/90 text-sm font-medium mb-2">
                      Plan Title
                    </label>
                    <input
                      type="text"
                      value={formData.title}
                      onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="e.g., Final Exam Preparation"
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all duration-200"
                      required
                    />
                  </div>
                  
                  {/* Description */}
                  <div>
                    <label className="block text-white/90 text-sm font-medium mb-2">
                      Description (Optional)
                    </label>
                    <textarea
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Describe your study goals and objectives..."
                      rows={3}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all duration-200 resize-none"
                    />
                  </div>
                  
                  {/* Subjects */}
                  <div>
                    <label className="block text-white/90 text-sm font-medium mb-3">
                      Select Subjects
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {subjects.slice(0, 9).map((subject) => (
                        <motion.button
                          key={subject.id}
                          type="button"
                          onClick={() => toggleSubject(subject.name)}
                          className={`p-3 rounded-xl border-2 transition-all duration-200 text-left ${
                            formData.subjects.includes(subject.name)
                              ? 'border-purple-400 bg-purple-500/20 text-white'
                              : 'border-white/20 bg-white/5 text-white/70 hover:border-white/30 hover:text-white'
                          }`}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <div className="text-sm font-medium">{subject.name}</div>
                          <div className="text-xs opacity-70">{subject.category}</div>
                        </motion.button>
                      ))}
                    </div>
                  </div>
                  
                  {/* Difficulty Level */}
                  <div>
                    <label className="block text-white/90 text-sm font-medium mb-2">
                      Primary Difficulty Level
                    </label>
                    <select
                      value={formData.difficulty_level}
                      onChange={(e) => setFormData(prev => ({ ...prev, difficulty_level: e.target.value }))}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all duration-200"
                    >
                      <option value="" className="bg-gray-800">Select difficulty level</option>
                      <option value="Elementary" className="bg-gray-800">Elementary</option>
                      <option value="Middle School" className="bg-gray-800">Middle School</option>
                      <option value="High School" className="bg-gray-800">High School</option>
                      <option value="College" className="bg-gray-800">College</option>
                    </select>
                  </div>
                  
                  {/* Weekly Goals */}
                  {formData.subjects.length > 0 && (
                    <div>
                      <label className="block text-white/90 text-sm font-medium mb-3">
                        Weekly Goals (Questions per week)
                      </label>
                      <div className="space-y-3">
                        {formData.subjects.map((subject) => (
                          <div key={subject} className="flex items-center justify-between">
                            <span className="text-white/80">{subject}</span>
                            <input
                              type="number"
                              min="1"
                              max="50"
                              value={formData.weekly_goals[subject] || ''}
                              onChange={(e) => updateWeeklyGoal(subject, parseInt(e.target.value) || 0)}
                              placeholder="10"
                              className="w-20 px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-center focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all duration-200"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="flex space-x-4 mt-8">
                  <button
                    type="button"
                    onClick={() => setShowCreateForm(false)}
                    className="flex-1 py-3 px-6 bg-white/10 border border-white/20 text-white rounded-xl font-semibold hover:bg-white/20 transition-all duration-200"
                  >
                    Cancel
                  </button>
                  
                  <button
                    type="submit"
                    disabled={createLoading || formData.subjects.length === 0}
                    className="flex-1 py-3 px-6 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl font-semibold hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center"
                  >
                    {createLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        Creating...
                      </>
                    ) : (
                      'Create Plan'
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default StudyPlans