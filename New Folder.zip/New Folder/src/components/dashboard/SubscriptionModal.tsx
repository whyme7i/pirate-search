import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  X, 
  Crown, 
  Zap, 
  CheckCircle, 
  Loader2,
  CreditCard,
  Shield,
  Star,
  TrendingUp
} from 'lucide-react'
import toast from 'react-hot-toast'

interface SubscriptionModalProps {
  isOpen: boolean
  onClose: () => void
  currentTier: 'free' | 'pro' | 'premium'
  isAdmin?: boolean
}

const SubscriptionModal = ({ isOpen, onClose, currentTier, isAdmin = false }: SubscriptionModalProps) => {
  const [selectedPlan, setSelectedPlan] = useState<'pro' | 'premium'>('pro')
  const [loading, setLoading] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState<'paypal' | 'card'>('paypal')

  const plans = {
    pro: {
      name: 'Pro',
      price: '$9.99',
      period: 'month',
      icon: <Zap className="w-6 h-6" />,
      color: 'from-purple-500 to-blue-500',
      features: [
        '50 questions per day',
        'All subjects including Programming',
        'File uploads up to 25MB',
        'Code debugging & explanations',
        'Camera photo capture',
        'Question history & favorites',
        'Detailed step-by-step solutions',
        'Priority support'
      ],
      savings: 'Perfect for serious students'
    },
    premium: {
      name: 'Premium',
      price: '$19.99',
      period: 'month',
      icon: <Crown className="w-6 h-6" />,
      color: 'from-yellow-400 to-orange-400',
      features: [
        'Unlimited questions',
        'File uploads up to 100MB',
        'Advanced camera features',
        'All file types (images, code, PDFs)',
        'Advanced coding tutorials',
        'Personalized study plans',
        'Code execution examples',
        'Plagiarism detection',
        'Exam preparation strategies',
        '24/7 premium support'
      ],
      savings: 'Ultimate academic toolkit',
      popular: true
    }
  }

  const handleSubscribe = async () => {
    setLoading(true)
    
    try {
      // Here you would integrate with PayPal SDK
      // For now, we'll simulate the subscription process
      
      if (paymentMethod === 'paypal') {
        // PayPal subscription flow
        toast.success('PayPal integration coming soon! Please contact support.')
      } else {
        // Card payment flow
        toast.success('Card payment integration coming soon! Please contact support.')
      }
      
      // In a real app, you would:
      // 1. Create PayPal subscription
      // 2. Handle payment confirmation
      // 3. Update user's subscription status
      // 4. Refresh user data
      
    } catch (error) {
      console.error('Subscription error:', error)
      toast.error('Failed to process subscription. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  // Admin users don't need subscription modal
  if (isAdmin) {
    return (
      <AnimatePresence>
        <motion.div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="bg-slate-900/95 backdrop-blur-sm rounded-3xl border border-white/20 max-w-md w-full p-8 text-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="admin-badge text-lg px-4 py-2 mb-4 inline-block">
              <Shield className="w-5 h-5 mr-2 inline" />
              ADMIN ACCESS
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">You have unlimited access!</h2>
            <p className="text-white/70 mb-6">As an admin, you have access to all premium features without any restrictions.</p>
            <button
              onClick={onClose}
              className="btn-premium px-6 py-3 bg-gradient-to-r from-yellow-400 to-orange-400 text-black rounded-xl font-semibold hover:opacity-90 transition-opacity"
            >
              Got it!
            </button>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    )
  }

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <motion.div
          className="bg-slate-900/95 backdrop-blur-sm rounded-3xl border border-white/20 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-8 border-b border-white/10">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">Upgrade Your Plan</h2>
              <p className="text-white/70">Unlock the full potential of AI-powered homework assistance</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Plan Selection */}
          <div className="p-8">
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {Object.entries(plans).map(([key, plan]) => {
                const isSelected = selectedPlan === key
                const isCurrentPlan = currentTier === key
                
                return (
                  <motion.div
                    key={key}
                    className={`relative rounded-2xl p-6 border-2 cursor-pointer transition-all duration-300 ${
                      isSelected
                        ? 'border-purple-400 bg-purple-500/10'
                        : 'border-white/20 bg-white/5 hover:border-white/30'
                    } ${isCurrentPlan ? 'opacity-50 cursor-not-allowed' : ''}`}
                    onClick={() => !isCurrentPlan && setSelectedPlan(key as 'pro' | 'premium')}
                    whileHover={!isCurrentPlan ? { scale: 1.02 } : {}}
                    whileTap={!isCurrentPlan ? { scale: 0.98 } : {}}
                  >
                    {'popular' in plan && plan.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center">
                        <Star className="w-4 h-4 mr-1" />
                        Most Popular
                      </div>
                    )}
                    
                    {isCurrentPlan && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                        Current Plan
                      </div>
                    )}

                    <div className="flex items-center space-x-3 mb-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${plan.color} flex items-center justify-center text-white`}>
                        {plan.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-white">{plan.name}</h3>
                        <p className="text-white/60 text-sm">{plan.savings}</p>
                      </div>
                    </div>

                    <div className="mb-6">
                      <div className="flex items-baseline space-x-2 mb-2">
                        <span className="text-4xl font-bold text-white">{plan.price}</span>
                        <span className="text-white/60">/{plan.period}</span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {plan.features.map((feature, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                          <span className="text-white/90">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )
              })}
            </div>

            {/* Payment Method Selection */}
            {currentTier !== selectedPlan && (
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-white mb-4">Payment Method</h3>
                <div className="grid grid-cols-2 gap-4">
                  <motion.button
                    onClick={() => setPaymentMethod('paypal')}
                    className={`p-4 rounded-xl border-2 transition-all duration-200 flex items-center space-x-3 ${
                      paymentMethod === 'paypal'
                        ? 'border-blue-400 bg-blue-500/10'
                        : 'border-white/20 bg-white/5 hover:border-white/30'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold">
                      P
                    </div>
                    <div className="text-left">
                      <div className="text-white font-medium">PayPal</div>
                      <div className="text-white/60 text-sm">Secure & trusted</div>
                    </div>
                  </motion.button>
                  
                  <motion.button
                    onClick={() => setPaymentMethod('card')}
                    className={`p-4 rounded-xl border-2 transition-all duration-200 flex items-center space-x-3 ${
                      paymentMethod === 'card'
                        ? 'border-purple-400 bg-purple-500/10'
                        : 'border-white/20 bg-white/5 hover:border-white/30'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <CreditCard className="w-8 h-8 text-purple-400" />
                    <div className="text-left">
                      <div className="text-white font-medium">Credit Card</div>
                      <div className="text-white/60 text-sm">Visa, Mastercard</div>
                    </div>
                  </motion.button>
                </div>
              </div>
            )}

            {/* Security & Benefits */}
            {/* New Features Highlight */}
            <div className="mb-8 p-6 glass rounded-xl">
              <h3 className="text-xl font-semibold text-white mb-4 text-center">🚀 New Enhanced Features</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-white font-medium">Advanced Coding Support</h4>
                    <p className="text-white/60 text-sm">Python, JavaScript, Java, C++, HTML/CSS</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                    <Shield className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-white font-medium">Camera Integration</h4>
                    <p className="text-white/60 text-sm">Instant photo capture for homework</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-teal-500 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-white font-medium">Smart File Upload</h4>
                    <p className="text-white/60 text-sm">Drag & drop with auto-detection</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
                    <Star className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-white font-medium">Enhanced AI Responses</h4>
                    <p className="text-white/60 text-sm">Code syntax highlighting & debugging</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="glass rounded-xl p-4 text-center">
                <Shield className="w-8 h-8 text-green-400 mx-auto mb-2" />
                <h4 className="text-white font-medium mb-1">Secure Payment</h4>
                <p className="text-white/60 text-sm">256-bit SSL encryption</p>
              </div>
              
              <div className="glass rounded-xl p-4 text-center">
                <TrendingUp className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                <h4 className="text-white font-medium mb-1">Instant Access</h4>
                <p className="text-white/60 text-sm">Immediate plan activation</p>
              </div>
              
              <div className="glass rounded-xl p-4 text-center">
                <X className="w-8 h-8 text-orange-400 mx-auto mb-2" />
                <h4 className="text-white font-medium mb-1">Cancel Anytime</h4>
                <p className="text-white/60 text-sm">No long-term commitment</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <button
                onClick={onClose}
                className="flex-1 py-4 px-6 bg-white/10 border border-white/20 text-white rounded-xl font-semibold hover:bg-white/20 transition-all duration-200"
              >
                Maybe Later
              </button>
              
              {currentTier !== selectedPlan && (
                <motion.button
                  onClick={handleSubscribe}
                  disabled={loading}
                  className={`flex-1 py-4 px-6 bg-gradient-to-r ${plans[selectedPlan].color} text-white rounded-xl font-semibold hover:opacity-90 transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center`}
                  whileHover={{ scale: loading ? 1 : 1.02 }}
                  whileTap={{ scale: loading ? 1 : 0.98 }}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      {plans[selectedPlan].icon}
                      <span className="ml-2">Subscribe to {plans[selectedPlan].name}</span>
                    </>
                  )}
                </motion.button>
              )}
            </div>
            
            <p className="text-white/50 text-xs text-center mt-4">
              By subscribing, you agree to our Terms of Service and Privacy Policy. 
              Your subscription will automatically renew monthly unless cancelled.
            </p>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

export default SubscriptionModal