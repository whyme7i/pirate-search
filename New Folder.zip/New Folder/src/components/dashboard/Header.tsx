import React from 'react'
import { motion } from 'framer-motion'
import { 
  Brain, 
  User, 
  Crown, 
  Zap, 
  LogOut,
  Settings,
  HelpCircle,
  Menu,
  Shield
} from 'lucide-react'
import { supabase } from '../../lib/supabase'
import { Database } from '../../lib/supabase'
import toast from 'react-hot-toast'

type Profile = Database['public']['Tables']['profiles']['Row']
type UsageTracking = Database['public']['Tables']['usage_tracking']['Row']

interface HeaderProps {
  profile: Profile
  usageData: UsageTracking | null
  onUpgradeClick: () => void
  onMenuClick?: () => void
  isAdmin?: boolean
}

const Header = ({ profile, usageData, onUpgradeClick, onMenuClick, isAdmin = false }: HeaderProps) => {
  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut()
      toast.success('Signed out successfully')
    } catch (error) {
      toast.error('Failed to sign out')
    }
  }

  const getTierColor = (tier: string) => {
    if (isAdmin) return 'from-yellow-400 to-orange-400'
    switch (tier) {
      case 'premium':
        return 'from-yellow-400 to-orange-400'
      case 'pro':
        return 'from-purple-400 to-blue-400'
      default:
        return 'from-gray-400 to-gray-500'
    }
  }

  const getTierIcon = (tier: string) => {
    if (isAdmin) return <Shield className="w-4 h-4" />
    switch (tier) {
      case 'premium':
        return <Crown className="w-4 h-4" />
      case 'pro':
        return <Zap className="w-4 h-4" />
      default:
        return <User className="w-4 h-4" />
    }
  }

  const getTierDisplayName = () => {
    if (isAdmin) return 'Admin'
    return profile.subscription_tier || 'free'
  }

  const remainingQuestions = usageData 
    ? Math.max(0, usageData.daily_limit - usageData.questions_asked)
    : (profile.subscription_tier === 'free' ? 5 : profile.subscription_tier === 'pro' ? 50 : 999)

  return (
    <header className="h-20 bg-black/20 backdrop-blur-sm border-b border-white/10 px-4 md:px-6 flex items-center justify-between safe-area-top">
      {/* Mobile Menu Button */}
      {onMenuClick && (
        <button
          onClick={onMenuClick}
          className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200 lg:hidden mr-3"
        >
          <Menu className="w-6 h-6" />
        </button>
      )}

      {/* Logo and Brand */}
      <motion.div 
        className="flex items-center space-x-3"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-blue-400 rounded-xl flex items-center justify-center">
          <Brain className="w-6 h-6 text-white" />
        </div>
        <div className="hidden sm:block">
          <h1 className="text-xl font-bold text-white">HomeworkAI</h1>
          <p className="text-white/60 text-sm">Your AI Study Companion</p>
        </div>
      </motion.div>

      {/* Usage Stats - Hidden on mobile */}
      <motion.div 
        className="hidden md:flex items-center space-x-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        {/* Daily Usage */}
        {!isAdmin && (
          <div className="glass rounded-lg px-4 py-2 text-center">
            <div className="text-white/60 text-xs font-medium mb-1">Today's Questions</div>
            <div className="text-white font-bold">
              {usageData?.questions_asked || 0} / {usageData?.daily_limit || (profile.subscription_tier === 'premium' ? '∞' : profile.subscription_tier === 'pro' ? '50' : '5')}
            </div>
            {profile.subscription_tier !== 'premium' && remainingQuestions <= 2 && (
              <div className="text-orange-400 text-xs mt-1">Running low!</div>
            )}
          </div>
        )}

        {/* Admin Badge or Subscription Tier */}
        <div className="flex items-center space-x-3">
          {isAdmin ? (
            <div className="admin-badge flex items-center space-x-2">
              <Shield className="w-4 h-4" />
              <span className="font-bold text-sm">ADMIN ACCESS</span>
            </div>
          ) : (
            <div className={`glass rounded-lg px-3 py-2 flex items-center space-x-2 bg-gradient-to-r ${getTierColor(profile.subscription_tier)}`}>
              {getTierIcon(profile.subscription_tier)}
              <span className="text-white font-medium capitalize text-sm">
                {getTierDisplayName()}
              </span>
            </div>
          )}
          
          {!isAdmin && profile.subscription_tier === 'free' && (
            <motion.button
              onClick={onUpgradeClick}
              className="btn-premium px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg font-medium text-sm hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Upgrade
            </motion.button>
          )}
        </div>
      </motion.div>

      {/* User Menu */}
      <motion.div 
        className="flex items-center space-x-2 md:space-x-4"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
      >
        {/* User Info - Hidden on mobile */}
        <div className="hidden md:block text-right">
          <div className="text-white font-medium">
            {profile.full_name || 'Student'}
            {isAdmin && <span className="text-yellow-400 ml-2">👑</span>}
          </div>
          <div className="text-white/60 text-sm">
            {profile.email}
          </div>
        </div>

        {/* Mobile Admin Badge */}
        {isAdmin && (
          <div className="md:hidden admin-badge text-xs px-2 py-1">
            <Shield className="w-3 h-3" />
          </div>
        )}

        {/* Profile Picture */}
        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
          isAdmin 
            ? 'bg-gradient-to-br from-yellow-400 to-orange-400' 
            : 'bg-gradient-to-br from-purple-400 to-pink-400'
        }`}>
          {isAdmin && <Shield className="w-5 h-5" />}
          {!isAdmin && (profile.full_name || profile.email || 'U').charAt(0).toUpperCase()}
        </div>

        {/* Quick Actions */}
        <div className="flex items-center space-x-1 md:space-x-2">
          <button 
            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200 hidden sm:block"
            title="Help"
          >
            <HelpCircle className="w-5 h-5" />
          </button>
          
          <button 
            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200 hidden sm:block"
            title="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
          
          <button 
            onClick={handleSignOut}
            className="p-2 text-white/60 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all duration-200"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4 md:w-5 md:h-5" />
          </button>
        </div>
      </motion.div>
    </header>
  )
}

export default Header