import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { 
  BookOpen, 
  Brain, 
  Zap, 
  Star, 
  Users, 
  CheckCircle, 
  ArrowRight,
  Calculator,
  Atom,
  Globe,
  Clock,
  FileText,
  Upload
} from 'lucide-react'
import FloatingParticles from './ui/FloatingParticles'
import FeatureCard from './ui/FeatureCard'
import PricingCard from './ui/PricingCard'
import { useAuth } from '../contexts/AuthContext'

const LandingPage = () => {
  const { user } = useAuth()
  const [currentFeature, setCurrentFeature] = useState(0)
  const [typedText, setTypedText] = useState('')
  const fullText = "Get instant homework help with AI-powered explanations"

  useEffect(() => {
    let index = 0
    const timer = setInterval(() => {
      if (index <= fullText.length) {
        setTypedText(fullText.slice(0, index))
        index++
      } else {
        clearInterval(timer)
      }
    }, 100)

    return () => clearInterval(timer)
  }, [])

  const features = [
    {
      icon: <Brain className="w-8 h-8" />,
      title: "AI-Powered Solutions",
      description: "Get instant, accurate answers with detailed explanations for any homework question."
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: "All Subjects + Coding",
      description: "From Mathematics to Programming - Python, JavaScript, Java, C++, and more!"
    },
    {
      icon: <Upload className="w-8 h-8" />,
      title: "Smart File Upload",
      description: "Upload images, code files, PDFs with drag & drop. Camera capture included!"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Code Debugging",
      description: "Advanced code analysis, debugging help, and syntax highlighting support."
    }
  ]

  const subjects = [
    { icon: <Calculator className="w-6 h-6" />, name: "Mathematics", color: "text-blue-400" },
    { icon: <Atom className="w-6 h-6" />, name: "Science", color: "text-green-400" },
    { icon: <BookOpen className="w-6 h-6" />, name: "Literature", color: "text-purple-400" },
    { icon: <Globe className="w-6 h-6" />, name: "Geography", color: "text-cyan-400" },
    { icon: <Clock className="w-6 h-6" />, name: "History", color: "text-yellow-400" },
    { icon: <FileText className="w-6 h-6" />, name: "Programming", color: "text-pink-400" }
  ]

  const pricingPlans = [
    {
      name: "Free",
      price: "$0",
      period: "forever",
      description: "Perfect for getting started",
      features: [
        "5 questions per day",
        "Basic subjects (Math, Science, English)",
        "Text-only questions",
        "Simple explanations",
        "Community support"
      ],
      limitations: [
        "No file uploads",
        "No camera features",
        "No history saving",
        "Limited subjects"
      ],
      buttonText: "Get Started Free",
      buttonVariant: "outline" as const,
      popular: false
    },
    {
      name: "Pro",
      price: "$9.99",
      period: "month",
      description: "For serious students",
      features: [
        "50 questions per day",
        "All subjects + Programming",
        "File uploads (25MB)",
        "Camera photo capture",
        "Code debugging help",
        "Question history",
        "Detailed explanations",
        "Priority support"
      ],
      limitations: [],
      buttonText: "Start Pro Trial",
      buttonVariant: "default" as const,
      popular: true
    },
    {
      name: "Premium",
      price: "$19.99",
      period: "month",
      description: "For academic excellence",
      features: [
        "Unlimited questions",
        "Large file uploads (100MB)",
        "Advanced camera features",
        "Code execution examples",
        "All file types support",
        "Personalized study plans",
        "Advanced coding tutorials",
        "Exam preparation",
        "24/7 premium support"
      ],
      limitations: [],
      buttonText: "Go Premium",
      buttonVariant: "premium" as const,
      popular: false
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-cyan-900 relative overflow-hidden">
      <FloatingParticles />
      
      {/* Navigation */}
      <nav className="relative z-20 flex items-center justify-between p-6 md:px-12">
        <motion.div 
          className="flex items-center space-x-3"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-blue-400 rounded-xl flex items-center justify-center">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <span className="text-2xl font-bold text-white">HomeworkAI</span>
        </motion.div>
        
        <motion.div 
          className="flex items-center space-x-6"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {user ? (
            <Link 
              to="/dashboard" 
              className="btn-premium px-6 py-2 bg-white/20 backdrop-blur-sm text-white rounded-lg border border-white/30 hover:bg-white/30 transition-all duration-300"
            >
              Dashboard
            </Link>
          ) : (
            <>
              <Link 
                to="/login" 
                className="text-white/80 hover:text-white transition-colors duration-200"
              >
                Login
              </Link>
              <Link 
                to="/signup" 
                className="btn-premium px-6 py-2 bg-white/20 backdrop-blur-sm text-white rounded-lg border border-white/30 hover:bg-white/30 transition-all duration-300"
              >
                Sign Up
              </Link>
            </>
          )}
        </motion.div>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 flex flex-col items-center justify-center min-h-[80vh] px-6 text-center">
        <motion.div
          className="max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center px-6 py-3 mb-8 bg-white/10 backdrop-blur-sm rounded-full border border-white/20"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Star className="w-5 h-5 text-yellow-400 mr-2" />
            <span className="text-white/90 text-sm font-medium">Trusted by 50,000+ students worldwide</span>
          </motion.div>

          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Your AI-Powered
            <br />
            <span className="bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
              Homework Assistant
            </span>
          </h1>

          <div className="text-xl md:text-2xl text-white/80 mb-8 h-8">
            <span className="border-r-2 border-purple-400 pr-1">
              {typedText}
            </span>
          </div>

          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Link
              to={user ? "/dashboard" : "/signup"}
              className="btn-premium group px-8 py-4 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl font-semibold text-lg hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300 flex items-center"
            >
              {user ? "Go to Dashboard" : "Start Free Today"}
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
            </Link>
            
            <button className="px-8 py-4 bg-white/10 backdrop-blur-sm text-white rounded-xl font-semibold text-lg border border-white/30 hover:bg-white/20 transition-all duration-300">
              Watch Demo
            </button>
          </motion.div>

          <motion.div
            className="mt-12 flex flex-wrap justify-center gap-6 text-white/60"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <div className="flex items-center">
              <CheckCircle className="w-5 h-5 text-green-400 mr-2" />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center">
              <CheckCircle className="w-5 h-5 text-green-400 mr-2" />
              <span>Instant setup</span>
            </div>
            <div className="flex items-center">
              <CheckCircle className="w-5 h-5 text-green-400 mr-2" />
              <span>24/7 AI support</span>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="relative z-10 py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Why Students Love HomeworkAI
            </h2>
            <p className="text-xl text-white/70 max-w-2xl mx-auto">
              Experience the future of homework assistance with our advanced AI technology
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <FeatureCard 
                key={index}
                {...feature}
                delay={index * 0.1}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section className="relative z-10 py-24 px-6 bg-black/20">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Master Every Subject
            </h2>
            <p className="text-xl text-white/70 mb-12">
              Get expert help across all academic disciplines
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            {subjects.map((subject, index) => (
              <motion.div
                key={index}
                className="glass rounded-xl p-6 text-center hover:scale-105 transition-all duration-300 cursor-pointer"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <div className={`${subject.color} mb-3 flex justify-center`}>
                  {subject.icon}
                </div>
                <h3 className="text-white font-semibold">{subject.name}</h3>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="relative z-10 py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Choose Your Plan
            </h2>
            <p className="text-xl text-white/70 max-w-2xl mx-auto">
              From free basic help to premium academic excellence - find the perfect plan for your needs
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <PricingCard
                key={index}
                {...plan}
                delay={index * 0.1}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative z-10 py-24 px-6">
        <motion.div
          className="max-w-4xl mx-auto text-center glass-strong rounded-3xl p-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Ace Your Homework?
          </h2>
          <p className="text-xl text-white/80 mb-8">
            Join thousands of students who are already improving their grades with HomeworkAI
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link
              to={user ? "/dashboard" : "/signup"}
              className="btn-premium px-8 py-4 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl font-semibold text-lg hover:from-purple-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-300"
            >
              {user ? "Go to Dashboard" : "Start Your Free Account"}
            </Link>
            
            <div className="text-white/60 text-sm">
              No credit card required • 5 free questions daily
            </div>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 py-12 px-6 border-t border-white/10">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-white">HomeworkAI</span>
          </div>
          <p className="text-white/60">
            © 2025 HomeworkAI. All rights reserved. Empowering students worldwide.
          </p>
        </div>
      </footer>
    </div>
  )
}

export default LandingPage