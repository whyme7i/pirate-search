import React from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { CheckCircle, X, Crown, Zap } from 'lucide-react'

interface PricingCardProps {
  name: string
  price: string
  period: string
  description: string
  features: string[]
  limitations: string[]
  buttonText: string
  buttonVariant: 'outline' | 'default' | 'premium'
  popular: boolean
  delay?: number
}

const PricingCard = ({ 
  name, 
  price, 
  period, 
  description, 
  features, 
  limitations, 
  buttonText, 
  buttonVariant, 
  popular,
  delay = 0
}: PricingCardProps) => {
  const getButtonClasses = () => {
    const base = "w-full py-4 px-6 rounded-xl font-semibold text-lg transition-all duration-300 transform hover:scale-105"
    
    switch (buttonVariant) {
      case 'outline':
        return `${base} border-2 border-white/30 text-white hover:bg-white/10 hover:border-white/50`
      case 'premium':
        return `${base} bg-gradient-to-r from-yellow-400 to-orange-400 text-black hover:from-yellow-500 hover:to-orange-500 shadow-lg`
      default:
        return `${base} bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600 shadow-lg`
    }
  }

  const getCardClasses = () => {
    if (popular) {
      return "glass-strong border-2 border-purple-400/50 shadow-xl shadow-purple-500/20 scale-105"
    }
    return "glass hover:scale-105"
  }

  return (
    <motion.div
      className={`relative rounded-3xl p-8 transition-all duration-300 ${getCardClasses()}`}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay }}
      viewport={{ once: true }}
      whileHover={{ y: popular ? 0 : -10 }}
    >
      {popular && (
        <motion.div 
          className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-2 rounded-full text-sm font-semibold flex items-center"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.4, delay: delay + 0.2 }}
        >
          <Crown className="w-4 h-4 mr-2" />
          Most Popular
        </motion.div>
      )}
      
      {name === 'Premium' && (
        <motion.div 
          className="absolute -top-2 -right-2 w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center"
          animate={{ 
            rotate: 360,
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            rotate: { duration: 20, repeat: Infinity, ease: "linear" },
            scale: { duration: 2, repeat: Infinity }
          }}
        >
          <Crown className="w-6 h-6 text-black" />
        </motion.div>
      )}

      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-white mb-2">{name}</h3>
        <p className="text-white/70 mb-6">{description}</p>
        
        <div className="flex items-baseline justify-center mb-2">
          <span className="text-5xl font-bold text-white">{price}</span>
          <span className="text-white/70 ml-2">/{period}</span>
        </div>
      </div>

      <div className="space-y-4 mb-8">
        {features.map((feature, index) => (
          <motion.div
            key={index}
            className="flex items-center text-white/90"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: delay + 0.1 * index }}
            viewport={{ once: true }}
          >
            <CheckCircle className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
            <span>{feature}</span>
          </motion.div>
        ))}
        
        {limitations.map((limitation, index) => (
          <motion.div
            key={index}
            className="flex items-center text-white/50"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: delay + 0.1 * (features.length + index) }}
            viewport={{ once: true }}
          >
            <X className="w-5 h-5 text-red-400 mr-3 flex-shrink-0" />
            <span className="line-through">{limitation}</span>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, delay: delay + 0.3 }}
        viewport={{ once: true }}
      >
        <Link
          to="/signup"
          className={`btn-premium ${getButtonClasses()} flex items-center justify-center group`}
        >
          {buttonVariant === 'premium' && (
            <Zap className="w-5 h-5 mr-2 group-hover:animate-pulse" />
          )}
          {buttonText}
        </Link>
      </motion.div>
      
      {name === 'Free' && (
        <p className="text-center text-white/60 text-sm mt-4">
          Perfect for trying out the platform
        </p>
      )}
      
      {popular && (
        <motion.div
          className="absolute inset-0 rounded-3xl bg-gradient-to-r from-purple-500/20 to-blue-500/20 pointer-events-none"
          animate={{
            opacity: [0.5, 0.8, 0.5]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      )}
    </motion.div>
  )
}

export default PricingCard