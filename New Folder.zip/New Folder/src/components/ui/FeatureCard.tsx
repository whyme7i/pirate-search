import React from 'react'
import { motion } from 'framer-motion'

interface FeatureCardProps {
  icon: React.ReactNode
  title: string
  description: string
  delay?: number
}

const FeatureCard = ({ icon, title, description, delay = 0 }: FeatureCardProps) => {
  return (
    <motion.div
      className="group glass rounded-2xl p-8 text-center hover:scale-105 transition-all duration-300 cursor-pointer"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay }}
      viewport={{ once: true }}
      whileHover={{ y: -10 }}
    >
      <motion.div 
        className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-purple-400 to-blue-400 rounded-xl mb-6 text-white"
        whileHover={{ 
          scale: 1.1,
          boxShadow: "0 20px 40px rgba(124, 58, 237, 0.3)"
        }}
        transition={{ duration: 0.2 }}
      >
        {icon}
      </motion.div>
      
      <h3 className="text-xl font-semibold text-white mb-4 group-hover:text-purple-300 transition-colors duration-200">
        {title}
      </h3>
      
      <p className="text-white/70 leading-relaxed">
        {description}
      </p>
      
      {/* Animated border effect */}
      <div className="absolute inset-0 rounded-2xl border border-transparent group-hover:border-purple-400/50 transition-all duration-300" />
    </motion.div>
  )
}

export default FeatureCard