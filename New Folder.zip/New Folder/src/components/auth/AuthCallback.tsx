import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { Loader2, CheckCircle, XCircle } from 'lucide-react'
import FloatingParticles from '../ui/FloatingParticles'

const AuthCallback = () => {
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading')
  const [message, setMessage] = useState('Verifying your account...')
  const navigate = useNavigate()

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        // Get the hash fragment from the URL
        const hashFragment = window.location.hash

        if (hashFragment && hashFragment.length > 0) {
          // Exchange the auth code for a session
          const { data, error } = await supabase.auth.exchangeCodeForSession(hashFragment)

          if (error) {
            console.error('Error exchanging code for session:', error.message)
            setStatus('error')
            setMessage('Failed to verify account. Please try signing in again.')
            setTimeout(() => {
              navigate('/login?error=' + encodeURIComponent(error.message))
            }, 3000)
            return
          }

          if (data.session) {
            setStatus('success')
            setMessage('Account verified successfully! Redirecting to dashboard...')
            
            // Wait a moment to show success, then redirect
            setTimeout(() => {
              navigate('/dashboard')
            }, 2000)
            return
          }
        }

        // If we get here, something went wrong
        setStatus('error')
        setMessage('No verification data found. Please try signing up again.')
        setTimeout(() => {
          navigate('/signup')
        }, 3000)
      } catch (error) {
        console.error('Auth callback error:', error)
        setStatus('error')
        setMessage('An unexpected error occurred. Please try again.')
        setTimeout(() => {
          navigate('/login')
        }, 3000)
      }
    }

    handleAuthCallback()
  }, [navigate])

  const getStatusIcon = () => {
    switch (status) {
      case 'loading':
        return <Loader2 className="w-12 h-12 text-blue-400 animate-spin" />
      case 'success':
        return <CheckCircle className="w-12 h-12 text-green-400" />
      case 'error':
        return <XCircle className="w-12 h-12 text-red-400" />
      default:
        return <Loader2 className="w-12 h-12 text-blue-400 animate-spin" />
    }
  }

  const getStatusColor = () => {
    switch (status) {
      case 'loading':
        return 'from-blue-500 to-purple-500'
      case 'success':
        return 'from-green-500 to-blue-500'
      case 'error':
        return 'from-red-500 to-orange-500'
      default:
        return 'from-blue-500 to-purple-500'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-cyan-900 relative overflow-hidden flex items-center justify-center">
      <FloatingParticles />
      
      <motion.div
        className="relative z-10 w-full max-w-md mx-6"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="glass-strong rounded-3xl p-8 border border-white/20 text-center">
          <motion.div
            className={`w-20 h-20 bg-gradient-to-br ${getStatusColor()} rounded-full flex items-center justify-center mx-auto mb-6`}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            {getStatusIcon()}
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h1 className="text-2xl font-bold text-white mb-4">
              {status === 'loading' && 'Verifying Account'}
              {status === 'success' && 'Welcome to HomeworkAI!'}
              {status === 'error' && 'Verification Failed'}
            </h1>
            
            <p className="text-white/80 leading-relaxed">
              {message}
            </p>
            
            {status === 'loading' && (
              <div className="mt-6">
                <div className="w-full bg-white/10 rounded-full h-2">
                  <motion.div
                    className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                </div>
              </div>
            )}
          </motion.div>
        </div>

        {/* Decorative elements */}
        <motion.div
          className="absolute -top-4 -left-4 w-24 h-24 bg-blue-500/20 rounded-full blur-xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute -bottom-4 -right-4 w-32 h-32 bg-purple-500/20 rounded-full blur-xl"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1,
          }}
        />
      </motion.div>
    </div>
  )
}

export default AuthCallback