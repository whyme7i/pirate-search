import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext'
import { motion } from 'framer-motion'
import { Loader2 } from 'lucide-react'
import FloatingParticles from '../ui/FloatingParticles'

interface ProtectedRouteProps {
  children: React.ReactNode
}

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const { user, loading } = useAuth()
  const location = useLocation()

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-cyan-900 relative overflow-hidden flex items-center justify-center">
        <FloatingParticles />
        
        <motion.div
          className="relative z-10 text-center"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <div className="glass-strong rounded-3xl p-8 border border-white/20">
            <motion.div
              className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-6"
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            >
              <Loader2 className="w-8 h-8 text-white animate-spin" />
            </motion.div>
            
            <h2 className="text-2xl font-bold text-white mb-2">Loading...</h2>
            <p className="text-white/70">Please wait while we verify your session</p>
          </div>
        </motion.div>
      </div>
    )
  }

  if (!user) {
    // Redirect to login page with return url
    return <Navigate to={`/login?returnTo=${encodeURIComponent(location.pathname)}`} replace />
  }

  return <>{children}</>
}

export default ProtectedRoute