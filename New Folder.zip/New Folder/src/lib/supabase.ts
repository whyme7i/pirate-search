import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://juljkfxuufmeazwxedxw.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp1bGprZnh1dWZtZWF6d3hlZHh3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcwNjExMzgsImV4cCI6MjA3MjYzNzEzOH0.kJ4HRdB0FqA-MJsURgEzRNl5HVDEJwW5Wzf1iEpqSTo'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          user_id: string
          email: string
          full_name: string | null
          subscription_tier: 'free' | 'pro' | 'premium'
          subscription_status: string
          paypal_subscription_id: string | null
          subscription_started_at: string | null
          subscription_ends_at: string | null
          is_admin: boolean | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          email: string
          full_name?: string | null
          subscription_tier?: 'free' | 'pro' | 'premium'
          subscription_status?: string
          paypal_subscription_id?: string | null
          subscription_started_at?: string | null
          subscription_ends_at?: string | null
          is_admin?: boolean | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          email?: string
          full_name?: string | null
          subscription_tier?: 'free' | 'pro' | 'premium'
          subscription_status?: string
          paypal_subscription_id?: string | null
          subscription_started_at?: string | null
          subscription_ends_at?: string | null
          is_admin?: boolean | null
          created_at?: string
          updated_at?: string
        }
      }
      subjects: {
        Row: {
          id: string
          name: string
          category: string
          difficulty_levels: string[]
          is_free_tier: boolean
          icon: string | null
          created_at: string
        }
      }
      questions: {
        Row: {
          id: string
          user_id: string
          subject_id: string | null
          question_text: string
          difficulty_level: string
          ai_response: string
          response_time_ms: number | null
          is_favorite: boolean
          has_file_upload: boolean
          file_urls: string[]
          created_at: string
          updated_at: string
        }
      }
      usage_tracking: {
        Row: {
          id: string
          user_id: string
          date: string
          questions_asked: number
          daily_limit: number
          tier: string
          created_at: string
          updated_at: string
        }
      }
      study_plans: {
        Row: {
          id: string
          user_id: string
          title: string
          description: string | null
          subjects: string[]
          difficulty_level: string | null
          weekly_goals: any
          progress_data: any
          is_active: boolean
          created_at: string
          updated_at: string
        }
      }
    }
  }
}